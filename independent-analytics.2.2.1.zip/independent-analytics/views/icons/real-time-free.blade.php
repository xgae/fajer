<svg width="140px" height="140px" viewBox="0 0 140 140" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <title>loading</title>
    <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
        <g id="loading" transform="translate(0.000000, 0.000000)" fill="#1F1A28" fill-rule="nonzero">
            <g id="Group" transform="translate(70.000000, 70.000000) rotate(180.000000) translate(-70.000000, -70.000000) ">
                <rect id="Rectangle" x="1.13686838e-13" y="0" width="20" height="140"></rect>
                <rect id="Rectangle" x="40" y="0" width="20" height="80"></rect>
                <rect id="Rectangle" x="80" y="0" width="20" height="100"></rect>
                <rect id="Rectangle" x="120" y="0" width="20" height="50"></rect>
            </g>
        </g>
    </g>
</svg>