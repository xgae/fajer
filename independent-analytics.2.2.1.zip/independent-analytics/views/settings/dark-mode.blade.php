<label class="column-label" for="iawp_dark_mode">
    <input type="checkbox" name="iawp_dark_mode" id="iawp_dark_mode" <?php checked(true, $dark_mode, true); ?>>
    <span><?php esc_html_e('Enable dark mode theme', 'independent-analytics'); ?></span>
</label>
