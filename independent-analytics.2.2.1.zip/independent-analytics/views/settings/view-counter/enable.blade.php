<label class="column-label" for="iawp_view_counter_enable">
    <input type="checkbox" name="iawp_view_counter_enable" id="iawp_view_counter_enable" <?php checked(true, $enable, true); ?>>
    <span><?php esc_html_e('Enable the view counter', 'independent-analytics'); ?></span>
</label>
